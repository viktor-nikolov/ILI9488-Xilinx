/* This header file is required by Adafruit_GFX library but has no meaning on AMD Xilinx SoCs.
 * I therefore created and empty file in order to keep changes to Adafruit_GFX library source codes to a minimum.
 */
