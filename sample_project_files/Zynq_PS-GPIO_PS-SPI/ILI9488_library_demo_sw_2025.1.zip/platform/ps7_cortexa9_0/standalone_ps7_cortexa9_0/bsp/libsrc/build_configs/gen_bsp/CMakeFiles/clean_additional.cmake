# Additional clean files
cmake_minimum_required(VERSION 3.16)

if("${CONFIG}" STREQUAL "" OR "${CONFIG}" STREQUAL "")
  file(REMOVE_RECURSE
  "C:\\MicroZed_projects\\2025.1\\ILI9488-Xilinx\\ZyboZ7_PS-GPIO_PS-SPI_sw\\platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\include\\sleep.h"
  "C:\\MicroZed_projects\\2025.1\\ILI9488-Xilinx\\ZyboZ7_PS-GPIO_PS-SPI_sw\\platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\include\\xiltimer.h"
  "C:\\MicroZed_projects\\2025.1\\ILI9488-Xilinx\\ZyboZ7_PS-GPIO_PS-SPI_sw\\platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\include\\xtimer_config.h"
  "C:\\MicroZed_projects\\2025.1\\ILI9488-Xilinx\\ZyboZ7_PS-GPIO_PS-SPI_sw\\platform\\ps7_cortexa9_0\\standalone_ps7_cortexa9_0\\bsp\\lib\\libxiltimer.a"
  )
endif()
