set(CMAKE_HOST_SYSTEM "Windows-10.0.26100")
set(CMAKE_HOST_SYSTEM_NAME "Windows")
set(CMAKE_HOST_SYSTEM_VERSION "10.0.26100")
set(CMAKE_HOST_SYSTEM_PROCESSOR "AMD64")

include("C:/MicroZed_projects/2025.1/ILI9488-Xilinx/ZyboZ7_PS-GPIO_PS-SPI_sw/platform/ps7_cortexa9_0/standalone_ps7_cortexa9_0/bsp/cortexa9_toolchain.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "cortexa9")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
